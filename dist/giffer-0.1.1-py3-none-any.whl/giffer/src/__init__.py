from ._util import make_gif
from ._pyplot_extension import Gif